create view result_final as
select `keyword`.`result_data`.`r_id`  AS `r_id`,
       `keyword`.`result_data`.`c_id`  AS `c_id`,
       `keyword`.`result_data`.`count` AS `count`,
       `keyword`.`keywords`.`t_id`     AS `t_id`
from (`keyword`.`result_data`
       join `keyword`.`keywords`)
where (`keyword`.`result_data`.`k_id` = `keyword`.`keywords`.`k_id`);

