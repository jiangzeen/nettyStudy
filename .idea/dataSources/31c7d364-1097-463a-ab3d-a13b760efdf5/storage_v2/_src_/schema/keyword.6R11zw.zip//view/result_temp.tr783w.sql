create view result_temp as
select `result_final`.`r_id`           AS `r_id`,
       `keyword`.`company`.`industry`  AS `industry`,
       `keyword`.`company`.`stockcode` AS `stockcode`,
       `keyword`.`company`.`stockname` AS `stockname`,
       `result_final`.`count`          AS `count`,
       `result_final`.`t_id`           AS `t_id`
from (`keyword`.`company`
       join `keyword`.`result_final`)
where (`keyword`.`company`.`c_id` = `result_final`.`c_id`);

