create view result_aims as
select `result_temp`.`r_id`           AS `r_id`,
       `result_temp`.`industry`       AS `industry`,
       `result_temp`.`stockcode`      AS `stockcode`,
       `result_temp`.`stockname`      AS `stockname`,
       `result_temp`.`count`          AS `count`,
       `keyword`.`type_target`.`name` AS `name`
from (`keyword`.`result_temp`
       join `keyword`.`type_target`)
where (`result_temp`.`t_id` = `keyword`.`type_target`.`t_id`);

